import fetch from 'node-fetch'
let handler = async (m, { conn, text }) => {
    await m.reply('*_ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ_*') 
    /*let res = `https://aemt.me/ai/text2img?text=${text}`
    conn.sendFile(m.chat, res.url, false, 'Nehhh Kak ><', m, false)*/
    const res = await fetch(`https://aemt.me/ai/text2img?text=${text}`);
    conn.sendFile(m.chat, res.url, false, 'ɴɪʜ ɢᴀᴍʙᴀʀɴʏᴀ', m, false)
}
handler.help = ['text2img']
handler.tags = ['ᴀɪ-ᴍᴇɴᴜ']
handler.command = /^(text2img)$/i
handler.limit = true
export default handler