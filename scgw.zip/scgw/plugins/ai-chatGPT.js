import fetch from "node-fetch";

const handler = async (m, { conn, text }) => {
  
  await m. reply(`*_ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ_*`) 
  if (!text) return conn.reply(m.chat, `
  [!] ᴍᴀsᴜᴋᴀɴ *ᴘᴇʀᴛᴀɴʏᴀᴀɴ*
  *ᴄᴏɴᴛᴏʜ:* .ai siapa presiden Indonesia`, m)
  try {
    const web = await fetch(`https://aemt.me/gpt4?text=${text}`)
    const result = await web.json()
    //conn.reply(m.chat, result.result, m)
    conn.reply(m.chat, result.result, m, {
      text: text,
      contextInfo: {
      externalAdReply: {
      title: `ʀɪᴢᴢ-ᴍᴅ | ᴄʜᴀᴛ-ɢᴘᴛ`,
      body: `© ᴄʀᴇᴀᴛᴇ ʙʏ: ʀɪᴢᴢ-ᴏғғᴄ`,
      thumbnailUrl: `http://free.xzcloud.org:1783/image/menu-thub.jpg`,
      sourceUrl: `https://chat.whatsapp.com/FJN1xoG1yrIIYbkwhYaYOD`,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}) 
  } catch (e) {
    conn.reply(m.chat, e.message, m)
  }
}


handler.help = ['ai']
handler.tags = ['ᴀɪ-ᴍᴇɴᴜ']
handler.command = /^((open)?ai)$/i
handler.limit = true

export default handler