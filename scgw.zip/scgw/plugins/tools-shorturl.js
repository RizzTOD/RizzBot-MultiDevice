import fetch from "node-fetch";

const handler = async (m, { conn, text }) => {
  
  await m. reply(`*_ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ_*`) 
  if (!text) return conn.reply(m.chat, `
  [!] ᴍᴀsᴜᴋᴀɴ *ʟɪɴᴋ ʏᴀɴɢ ᴀᴋᴀɴ ᴅɪ ᴘᴇɴᴅᴇᴋᴀɴ*
  *ᴄᴏɴᴛᴏʜ:* .shorturl https://google.com`, m)
  try {
    const web = await fetch(`https://aemt.me/vurl?link=${text}`)
    const result = await web.json()
    //conn.reply(m.chat, result.result, m)
    conn.reply(m.chat, result.result, m, {
      text: text,
      contextInfo: {
      externalAdReply: {
      title: `ʀɪᴢᴢ-ᴍᴅ | ᴄʜᴀᴛ-ɢᴘᴛ`,
      body: `© ᴄʀᴇᴀᴛᴇ ʙʏ: ʀɪᴢᴢ-ᴏғғᴄ`,
      thumbnailUrl: `http://free.xzcloud.org:1783/image/menu-thub.jpg`,
      sourceUrl: `https://chat.whatsapp.com/FJN1xoG1yrIIYbkwhYaYOD`,
      mediaType: 1,
      renderLargerThumbnail: true
      }}}) 
  } catch (e) {
    conn.reply(m.chat, e.message, m)
  }
}


handler.help = ['shorturl']
handler.tags = ['ᴛᴏᴏʟs-ᴍᴇɴᴜ']
handler.command = /^(shorturl)$/i
handler.limit = true

export default handler