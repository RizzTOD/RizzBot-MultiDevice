import fetch from "node-fetch";

const handler = async (m, { conn, text }) => {
  
  await m. reply(`*_ʟ ᴏ ᴀ ᴅ ɪ ɴ ɢ_*`) 
  if (!text) return conn.reply(m.chat, `
  [!] ᴍᴀsᴜᴋᴀɴ *ᴘᴇʀᴛᴀɴʏᴀᴀɴ*
  *ᴄᴏɴᴛᴏʜ:* .ai siapa presiden Indonesia`, m)
  try {
    const web = await fetch(`https://aemt.me/bingimg?text=${text}`)
    const result = await web.json()
    //conn.reply(m.chat, result.result, m)
    conn.sendFile(m.chat, result.result, false, 'ɴɪʜ ɢᴀᴍʙᴀʀɴʏᴀ', m, false)
  } catch (e) {
    conn.reply(m.chat, e.message, m)
  }
}


handler.help = ['bingimg']
handler.tags = ['ᴀɪ-ᴍᴇɴᴜ']
handler.command = /^(bingimg)$/i
handler.limit = true

export default handler